Reflex is broken, leave it off it harms 1% lows
If DLSS/FSR is turned on, Anti-Aliasing will be enabled