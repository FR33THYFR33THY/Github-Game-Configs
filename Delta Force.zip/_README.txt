How to Play the Full Release Version of Delta Force China:

1. Link your mobile number to your Facebook account.
2. Download the WeChat mobile app and create a new account using your Facebook account and same mobile number.
3. Visit https://df.qq.com/ on your Windows PC and install the game launcher.
4. Use the Google Translate app with your phone’s camera to translate any on-screen text if needed.
5. Log in to the launcher by scanning the QR code with WeChat on your phone. You can choose a different in-game name during this step.

-

Config files are located in.
Steam\steamapps\common\Delta Force Demo\Game\DeltaForce\Saved\Config\WindowsClient

-

Reflex is currently not functional and is using an outdated version, which negatively impacts FPS and 1% lows.
This may improve once NVIDIA releases an updated driver with support for the game.

-

Anti-Aliasing is disabled by default in the config.
However, if DLSS, FSR, or other upscaling methods are enabled, Anti-Aliasing will be automatically turned on.
To disable it again, simply turn off DLSS, FSR, or upscaling and restart the game.

-

There is currently no dedicated profile for this game in NVIDIA drivers.
Go to NVIDIA Control Panel - Manage 3D Settings - Program Settings - Add - "Select DFM" - Add Selected Program - Apply.

-

To reload shaders open "UserSystemSettingHD.ini" in notepad, you will see.

[FirstLaunchSetting]
PSODone=X.XXX.XXXX.XX

Delete the text after "PSODone="
It should look like this

[FirstLaunchSetting]
PSODone=

Save the notepad file and launch the game, shaders should reload.