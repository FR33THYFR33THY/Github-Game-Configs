Set "RendererWorkerCount" to cpu cores -1
As an example 8700k has 8 cores = 7

12th, 13th, 14th gen with ecores - set number as performance cores
As an example 13900k has 8 performance cores and 16 ecores = 7

7900x3d, 7950x3d if using gamebar to park cores with ccd1 on - set number as x3d cores
As an example 7950x3d has ccd0 8 x3d cores and ccd1 8 non x3d cores = 7

Variable rate shading is on for more frames

Rebar is off as this causes bad 1% lows in this engine